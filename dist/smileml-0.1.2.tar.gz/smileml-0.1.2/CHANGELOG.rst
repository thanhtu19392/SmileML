
Changelog
=========

0.1.0 (2017-08-21)
------------------

* First release on PyPI.
