=====
Usage
=====

To use Dodoml in a project::

	import dodoml
