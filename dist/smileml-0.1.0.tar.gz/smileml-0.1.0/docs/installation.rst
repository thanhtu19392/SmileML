============
Installation
============

At the command line::

    python setup.py install
