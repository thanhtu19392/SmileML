# SmileML

SmileML is a toolbox which helps us to facilitate the process of using pipeline in sklearn. It's built on python 3.6

## Installation
pip install smileml 
